# DodgeyShoot

## Index
### Game Elevator Pitch
In this **intense**, **fast-paced** 2D-shooter you need to fight your way to freedom in a seemingly endless wave of enemies, known as **_The Sprites_**. The Sprites are evil creatures that want to keep you from getting to your destination; **_"The End"_**.

## Proposal
### Genre
Horizontal Dodging/Vertical Shooter
### Platform
Desktop only
### Story
No _actual_ story
### Esthetics
Pixelly art and 8-bit audio
### GDD for DodgeyShoot
Here a more in-depth game design document will be written out with ideas, controls, plans, etc.

## Documentation
### Progress
* Document progress along the project

### Obstacles Faced
* Document obstacles that come up
* Document how those obstacles are overcome

## Project
### Placeholder "cutout" for plalcement of game when implemented
This page will possess a 'plot' in which the game will sit once it is implemented

# Heads-up
This content document is a little lacking because I was under the impression the assignment that was due was the html/css mockup of our website and have begun implementation of it [here](https://people.rit.edu/wjb5377/230/project1/)